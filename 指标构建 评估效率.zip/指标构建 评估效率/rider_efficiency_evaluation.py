import pandas as pd
import numpy as np
from scipy.stats import entropy

def normalize_indicators(data):
    """使用最小-最大规范化方法处理指标数据"""
    eps = 1e-10
    min_vals = np.min(data, axis=0)
    max_vals = np.max(data, axis=0)
    
    # 处理最大值等于最小值的情况
    range_vals = max_vals - min_vals
    range_vals[range_vals == 0] = eps
    
    normalized = (data - min_vals) / range_vals
    return normalized * 0.99 + 0.01  # 避免出现0值

def calculate_entropy_weights(normalized_data):
    """使用熵值法计算指标权重"""
    # 计算每个指标的熵值
    n_samples = normalized_data.shape[0]
    entropies = []
    
    for j in range(normalized_data.shape[1]):
        # 计算概率
        p_ij = normalized_data[:, j] / np.sum(normalized_data[:, j])
        # 计算熵值
        e_j = -np.sum(p_ij * np.log(p_ij + 1e-10)) / np.log(n_samples)
        entropies.append(e_j)
    
    # 计算差异系数
    g_j = 1 - np.array(entropies)
    # 计算权重
    weights = g_j / np.sum(g_j)
    return weights

def fuzzy_comprehensive_evaluation(data, weights):
    """模糊综合评价"""
    # 构建隶属度矩阵
    membership_matrix = np.zeros((len(data), 3))  # 3个等级
    
    for i in range(len(data)):
        # 三个等级的分级标准
        if data[i] < 0.4:  
            membership_matrix[i] = [0.7, 0.3, 0]
        elif data[i] < 0.7:
            membership_matrix[i] = [0.2, 0.6, 0.2]
        else:
            membership_matrix[i] = [0, 0.3, 0.7]
    
    # 计算每个样本的得分
    grade_values = np.array([0.3, 0.6, 0.9])  # 三个等级对应的分值
    scores = np.dot(membership_matrix, grade_values)
    
    # 根据权重计算最终得分
    final_scores = scores * np.mean(weights)
    
    return final_scores

def calculate_advanced_efficiency(df_day):
    """计算高级效率指标（按天计算）"""
    # 计算基础指标
    eps = 1e-10
    
    # 1. 计算有效准时单量（使用准时率的平方）
    df_day['adjusted_ontime_rate_squared'] = df_day['adjusted_ontime_rate'] ** 2
    df_day['effective_ontime_deliveries'] = df_day['cnt_waybill'] * df_day['adjusted_ontime_rate_squared']
    
    # 2. 计算两个核心效率指标
    df_day['time_efficiency'] = df_day['effective_ontime_deliveries'] / (df_day['interval_work'] + eps)  # 时间效率
    df_day['cost_efficiency'] = df_day['effective_ontime_deliveries'] / (df_day['TPO'] + eps)  # 成本效率
    
    # 3. 构建评价指标矩阵
    indicators = np.column_stack([
        df_day['time_efficiency'].values,
        df_day['cost_efficiency'].values
    ])
    
    # 4. 数据规范化（在当天数据范围内进行）
    normalized_indicators = normalize_indicators(indicators)
    
    # 5. 计算熵值权重（在当天数据范围内计算）
    entropy_weights = calculate_entropy_weights(normalized_indicators)
    
    # 6. 计算加权得分
    weighted_scores = np.dot(normalized_indicators, entropy_weights)
    
    # 7. 模糊综合评价
    final_efficiency = fuzzy_comprehensive_evaluation(weighted_scores, entropy_weights)
    
    # 8. 保存结果
    df_day['entropy_weighted_efficiency'] = weighted_scores
    df_day['final_efficiency_score'] = final_efficiency
    
    # 9. 计算效率等级（按照20%-60%-20%的比例划分）
    score_percentiles = np.percentile(final_efficiency, [20, 80])
    conditions = [
        final_efficiency <= score_percentiles[0],  # 底部20%
        (final_efficiency > score_percentiles[0]) & (final_efficiency <= score_percentiles[1]),  # 中间60%
        final_efficiency > score_percentiles[1]  # 顶部20%
    ]
    choices = ['一般', '良好', '优秀']
    df_day['efficiency_level'] = np.select(conditions, choices)
    
    return df_day

def main():
    # 读取数据
    print("正在读取数据...")
    file_path = r"D:\美团商分\选题一\指标构建.xlsx"
    df = pd.read_excel(file_path)
    print(f"总共读取了 {len(df)} 条数据")
    
    # 按日期分组分析
    print("\n按日期分组分析...")
    all_results = []
    
    # 获取所有唯一日期
    unique_dates = df['dt'].unique()
    print(f"数据集中包含 {len(unique_dates)} 个不同日期")
    
    for date in unique_dates:
        # 筛选当天数据
        df_day = df[df['dt'] == date].copy()
        print(f"\n分析日期: {date}")
        
        # 计算当天的效率指标
        df_day = calculate_advanced_efficiency(df_day)
        
        # 显示当天效率等级分布
        print(f"\n{date} 效率等级分布:")
        level_dist = df_day['efficiency_level'].value_counts().sort_index()
        print(level_dist)
        print("\n各等级占比：")
        print((level_dist / len(df_day) * 100).round(2), '%')
        
        # 收集结果
        all_results.append(df_day)
    
    # 合并所有结果
    df_results = pd.concat(all_results)
    print(f"\n总共分析了 {len(df_results)} 条记录")
    
    # 保存结果
    output_path = r"D:\美团商分\选题一\rider_efficiency_results.xlsx"
    df_results.to_excel(output_path, index=False)
    print(f"\n结果已保存到: {output_path}")

if __name__ == "__main__":
    main() 