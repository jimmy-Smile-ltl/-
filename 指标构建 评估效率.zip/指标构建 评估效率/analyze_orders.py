import pandas as pd
import os

def calculate_metrics(file_path):
    try:
        # 读取Excel文件
        print(f"正在读取Excel文件: {file_path}")
        df = pd.read_excel(file_path)
        
        # 显示数据基本信息
        print("\n数据基本信息：")
        print(df.info())
        
        # 1. 计算每个骑手的订单完成率(OCR)
        # 首先找出每天订单量最多的骑手的单量
        daily_max_orders = df.groupby('dt')['cnt_waybill'].max().reset_index()
        daily_max_orders.columns = ['dt', 'max_daily_orders']
        
        # 将最大订单数合并到原始数据中
        df = df.merge(daily_max_orders, on='dt', how='left')
        
        # 计算OCR
        df['OCR'] = df['cnt_waybill'] / df['max_daily_orders']
        
        # 2. 计算单位订单工作时长(TPO)
        df['TPO'] = df['interval_waybill'] / df['cnt_waybill']
        
        # 保存结果到原文件相同目录
        output_path = os.path.join(os.path.dirname(file_path), 'result_with_OCR_TPO.xlsx')
        print(f"\n正在保存结果到: {output_path}")
        df.to_excel(output_path, index=False)
        print("文件保存成功！")
        
        # 显示一些统计信息
        print("\n新增指标的统计信息：")
        print("\nOCR（订单完成率）统计：")
        print(df['OCR'].describe())
        print("\nTPO（单位订单工作时长）统计：")
        print(df['TPO'].describe())
        
        # 显示每日OCR和TPO的平均值
        daily_stats = df.groupby('dt').agg({
            'OCR': 'mean',
            'TPO': 'mean'
        }).reset_index()
        
        print("\n每日平均OCR和TPO：")
        print(daily_stats.sort_values('dt'))
        
    except FileNotFoundError:
        print(f"错误：找不到指定的文件: {file_path}")
        print("请确保文件路径正确，且文件存在")
    except Exception as e:
        print(f"处理数据时出错：{str(e)}")
        print("错误详细信息：", e.__class__.__name__)

if __name__ == "__main__":
    file_path = r"D:\美团商分\选题一\result_analyzed.xlsx"
    calculate_metrics(file_path) 